# janjapan-backend
Janjapan backend API
Laravel

Laravel v9.52.7 (PHP v8.0.2)

Packages

aws sdk php laravel
commond: composer require aws/aws-sdk-php-laravel

socialite
commond: composer require laravel/socialite

phpoffice phpspreadsheet

commond: composer require phpoffice/phpspreadsheet

PHP GoogleAnalytics4 Measurement Protocol Library

commond: composer require br33f/php-ga4-mp

Passport Token For token
